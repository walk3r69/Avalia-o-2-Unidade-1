package com.example.ponei;

import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import androidx.appcompat.app.AlertDialog;

public class goat extends View {

    private Paint paint;
    private Paint concentricPaint;
    private int currentColor;
    private SharedPreferences preferences;
    private static final String PREFS_NAME = "PoneiAppPrefs";
    private static final String COLOR_KEY = "circle_color";

    public goat(Context context, AttributeSet attrs) {
        super(context, attrs);

        // Inicializa as preferências
        preferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);

        // Obtém a cor padrão do strings.xml
        int defaultColorString = getResources().getIdentifier("default_color", "string", context.getPackageName());
        int defaultColor = defaultColorString != 0 ? Color.parseColor(getResources().getString(defaultColorString)) : Color.BLUE; // Fallback para azul

        // Define a cor inicial (preferência > strings.xml > Azul)
        currentColor = preferences.getInt(COLOR_KEY, defaultColor);

        // Inicializa o Paint
        paint = new Paint();
        paint.setColor(currentColor);

        concentricPaint = new Paint();
        concentricPaint.setStyle(Paint.Style.STROKE);
        concentricPaint.setStrokeWidth(5);
        concentricPaint.setColor(Color.BLACK); // Cor preta para o grid
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int x = getWidth() / 2;
        int y = getHeight() / 2;
        int radius = Math.min(x, y) - 50;

        // Desenhar o círculo principal
        paint.setColor(currentColor);
        canvas.drawCircle(x, y, radius, paint);

        // Desenhar 3 círculos concêntricos dentro do círculo principal
        int concentricCircles = 3;
        int step = radius / (concentricCircles + 1);

        for (int i = 1; i <= concentricCircles; i++) {
            canvas.drawCircle(x, y, radius - i * step, concentricPaint);
        }

        // Desenhar a borda preta fora do círculo principal
        concentricPaint.setStrokeWidth(5); // Borda mais grossa
        canvas.drawCircle(x, y, radius, concentricPaint);

        // Desenhar linhas ortogonais (horizontal e vertical)
        canvas.drawLine(x - radius, y, x + radius, y, concentricPaint); // Linha horizontal
        canvas.drawLine(x, y - radius, x, y + radius, concentricPaint); // Linha vertical
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            showColorPickerDialog();
            return true;
        }
        return false;
    }

    private void showColorPickerDialog() {
        final String[] colors = {"Vermelho", "Verde", "Azul"};
        final int[] colorValues = {Color.RED, Color.GREEN, Color.BLUE};

        // Salva a cor atual antes de abrir o diálogo
        final int previousColor = currentColor;

        int checkedItem = -1;
        for (int i = 0; i < colorValues.length; i++) {
            if (currentColor == colorValues[i]) {
                checkedItem = i;
                break;
            }
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setTitle("Selecione a cor")
                .setSingleChoiceItems(colors, checkedItem, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Atualiza a cor temporária ao selecionar
                        currentColor = colorValues[which];
                    }
                })
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Aplica a nova cor ao Paint e redesenha
                        paint.setColor(currentColor);
                        invalidate(); // Redesenhar o círculo

                        // Salva a cor nas preferências
                        SharedPreferences.Editor editor = preferences.edit();
                        editor.putInt(COLOR_KEY, currentColor);
                        editor.apply();
                    }
                })
                .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Reverte para a cor anterior se "Cancelar" for clicado
                        currentColor = previousColor;
                        invalidate(); // Redesenhar o círculo com a cor antiga
                    }
                })
                .create()
                .show();
    }
}
